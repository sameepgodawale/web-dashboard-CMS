// Shared frontend app.js
const state = { incidents: [], devices: [], vehiclesOnline: 124, rsus:12, avgLatency:120 };
function refreshKPIs(){ document.getElementById('kpiActiveAlerts').innerText = state.incidents.filter(i=>i.status!=='ack').length; document.getElementById('kpiVehicles').innerText = state.vehiclesOnline; document.getElementById('kpiRsus').innerText = state.rsus; document.getElementById('kpiLatency').innerText = state.avgLatency + ' ms'; }
const map = typeof L !== 'undefined' ? L.map('map' || 'mapInc').setView([19.0760,72.8777], 12) : null;
if(map){ L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map); }
let markers = {};
function addIncidentMarker(inc, mapRef=this.map||map){ if(!mapRef) return; const key=inc.id; const marker = L.circleMarker([inc.lat,inc.lng],{radius:10,color: inc.severity==='high'? '#d9534f': inc.severity==='medium'? '#f0ad4e':'#5cb85c'}).addTo(mapRef); marker.bindPopup(`<b>Incident ${inc.id}</b><br>Vehicle: ${inc.vehicle}<br>Time: ${new Date(inc.ts).toLocaleString()}<br>Confidence: ${inc.confidence}%`); markers[key]=marker; }
function renderLive(){ const feed=document.getElementById('liveFeed'); if(feed){ feed.innerHTML=''; state.incidents.slice().reverse().slice(0,8).forEach(i=>{ const el=document.createElement('div'); el.className='mb-1'; el.innerHTML=`<strong>Incident ${i.id}</strong> — ${i.summary} <span class='text-muted small'>${new Date(i.ts).toLocaleTimeString()}</span>`; feed.appendChild(el); }); } const recent=document.getElementById('recentIncidents'); if(recent){ recent.innerHTML=''; state.incidents.slice().reverse().slice(0,6).forEach(i=>{ const tr=document.createElement('tr'); tr.innerHTML=`<td>${i.id}</td><td>${new Date(i.ts).toLocaleTimeString()}</td><td><span class='badge ${i.severity==='high'?'badge-sev-high':i.severity==='medium'?'badge-sev-med':'badge-sev-low'}'>${i.severity}</span></td>`; recent.appendChild(tr); }); } const logT=document.querySelector('#logTable tbody'); if(logT){ logT.innerHTML=''; state.incidents.slice().reverse().forEach(i=>{ const r=document.createElement('tr'); r.innerHTML=`<td>${i.id}</td><td>${new Date(i.ts).toLocaleString()}</td><td>${i.vehicle}</td><td>${i.rsu}</td><td>${i.confidence}%</td><td><button class='btn btn-sm btn-primary' onclick=\"ack('${i.id}')\">Acknowledge</button></td>`; logT.appendChild(r); }); } const devT=document.querySelector('#deviceTable tbody'); if(devT){ devT.innerHTML=''; state.devices.forEach(d=>{ const r=document.createElement('tr'); r.innerHTML=`<td>${d.id}</td><td>${d.type}</td><td>${d.status}</td><td>${new Date(d.lastSeen).toLocaleTimeString()}</td>`; devT.appendChild(r); }); } }
function ack(id){ const it=state.incidents.find(x=>x.id===id); if(it) it.status='ack'; if(markers[id]) markers[id].setStyle({opacity:0.5}); renderLive(); refreshKPIs(); }
const chart = typeof ApexCharts !== 'undefined' ? new ApexCharts(document.querySelector('#chart'),{ chart:{type:'area',height:220,animations:{enabled:false}}, series:[{name:'Packet Delivery %',data:[98,97,99,96,97,95,98]}], xaxis:{categories:['T-6','T-5','T-4','T-3','T-2','T-1','Now']} }) : null; if(chart) chart.render();
// seed devices
for(let i=1;i<=12;i++) state.devices.push({id:`RSU-${i}`,type:'RSU',status: i%5===0?'Offline':'Online', lastSeen: Date.now()- (i*60000)});
for(let i=1;i<=40;i++) state.devices.push({id:`OBU-${100+i}`,type:'OBU',status: 'Online', lastSeen: Date.now()-(i*12000)});
refreshKPIs(); renderLive();
// simulate alert
function simulateAlert(){ const id='INC-'+ (1000 + Math.floor(Math.random()*9000)); const lat=19.03 + Math.random()*0.2; const lng=72.75 + Math.random()*0.3; const sev=Math.random()>0.7? 'high': Math.random()>0.4? 'medium':'low'; const conf=Math.floor(60 + Math.random()*40); const inc={id,lat,lng,severity:sev,confidence:conf,vehicle:'VEH-'+Math.floor(Math.random()*999),rsu:'RSU-'+(1+Math.floor(Math.random()*12)),ts:Date.now(),summary:`Detected ${sev} severity event`,status:'new'}; state.incidents.push(inc); try{ addIncidentMarker(inc); }catch(e){} refreshKPIs(); renderLive(); // broadcast to backend\n if(ws && ws.readyState===1) ws.send(JSON.stringify({type:'incident_ack',id:inc.id})); }\nif(document.getElementById('simulateBtn')) document.getElementById('simulateBtn').addEventListener('click', simulateAlert);\nwindow.addEventListener('keydown',(e)=>{ if(e.key==='a' || e.key==='A') simulateAlert(); });\n// WebSocket connection to backend\nlet ws; try{ ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://') + location.host + '/ws'); ws.onopen=()=>console.log('WS connected'); ws.onmessage=(ev)=>{ try{ const msg=JSON.parse(ev.data); if(msg.type==='incident') { state.incidents.push(msg.data); addIncidentMarker(msg.data); renderLive(); refreshKPIs(); } }catch(e){console.error(e);} }; ws.onclose=()=>console.log('WS closed'); }catch(e){console.warn('WS init failed',e);}

// Helper: auth token
function getAuthToken(){ return localStorage.getItem('vanet_token'); }
function authHeaders(h){ h = h || {}; const t=getAuthToken(); if(t) h['Authorization']='Bearer '+t; return h; }

// override fetch for protected calls (simple wrapper)
async function apiFetch(path, opts){ opts = opts || {}; opts.headers = authHeaders(opts.headers || {}); if(opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body); if(opts.body) opts.headers['Content-Type']='application/json'; const r = await fetch(path, opts); if(r.status===401){ console.warn('401 from API - redirect to login'); window.location='/login.html'; } return r; }

// Reconnect WS with token as query param
function initWS(){
  try{
    const token = getAuthToken();
    const proto = (location.protocol==='https:') ? 'wss' : 'ws';
    const host = location.host;
    const wsUrl = `${proto}://${host}/ws${token?('?token='+encodeURIComponent(token)):''}`;
    ws = new WebSocket(wsUrl);
    ws.onopen = ()=>console.log('WS connected');
    ws.onmessage = (ev)=>{ try{ const msg = JSON.parse(ev.data); if(msg.type==='incident'){ state.incidents.push(msg.data); addIncidentMarker(msg.data); renderLive(); refreshKPIs(); } }catch(e){console.error(e);} };
    ws.onclose = ()=>{ console.log('WS closed, retrying in 3s'); setTimeout(initWS,3000); };
  }catch(e){ console.warn('WS init failed', e); }
}
// start WS after load
initWS();
