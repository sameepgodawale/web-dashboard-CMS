-- init_db.sql: create tables for VANET CMS demo
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT DEFAULT 'operator'
);

CREATE TABLE IF NOT EXISTS devices (
  id SERIAL PRIMARY KEY,
  device_id TEXT UNIQUE NOT NULL,
  type TEXT,
  status TEXT,
  last_seen BIGINT
);

CREATE TABLE IF NOT EXISTS incidents (
  id SERIAL PRIMARY KEY,
  incident_id TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  severity TEXT,
  confidence INT,
  vehicle TEXT,
  rsu TEXT,
  ts BIGINT,
  summary TEXT,
  status TEXT
);

-- seed an admin (password: adminpass) - change in production
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM users WHERE username='admin') THEN
    INSERT INTO users(username, password_hash, role) VALUES('admin', '$2b$10$T6kq1Q7a0nq2nbY8rjzU.OJx8u3qvWk1z1o3GqvI3b6nS1xYx8k9e', 'admin');
  END IF;
END$$;
