// Simple Node.js server for VANET CMS demo
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path:'/ws' });
const DATA_FILE = path.join(__dirname, 'data','db.json');
if(!fs.existsSync(path.join(__dirname,'data'))) fs.mkdirSync(path.join(__dirname,'data'));
if(!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({devices:[],incidents:[]},null,2));

function readDB(){ return JSON.parse(fs.readFileSync(DATA_FILE)); }
function writeDB(d){ fs.writeFileSync(DATA_FILE, JSON.stringify(d,null,2)); }

app.use(express.json());
app.use('/', express.static(path.join(__dirname, 'public')));

// REST endpoints
app.get('/api/devices', (req,res)=>{ const db=readDB(); res.json(db.devices); });
app.get('/api/incidents', (req,res)=>{ const db=readDB(); res.json(db.incidents); });
app.post('/api/incidents', (req,res)=>{ const db=readDB(); const inc = req.body; inc.ts = inc.ts || Date.now(); db.incidents.push(inc); writeDB(db); // broadcast\n broadcast({type:'incident', data: inc}); res.json({ok:true}); });

function broadcast(msg){ const s = JSON.stringify(msg); wss.clients.forEach(c=>{ if(c.readyState===WebSocket.OPEN) c.send(s); }); }

wss.on('connection',(ws)=>{ console.log('Client connected via WS'); ws.on('message',(m)=>{ try{ const msg = JSON.parse(m); if(msg.type==='ping') ws.send(JSON.stringify({type:'pong'})); }catch(e){} }); ws.on('close',()=>console.log('WS client disconnected')); });

// Simulate incidents periodically (for demo)
setInterval(()=>{ const inc = { id: 'INC-'+ (1000 + Math.floor(Math.random()*9000)), lat: 19.03 + Math.random()*0.2, lng:72.75 + Math.random()*0.3, severity: Math.random()>0.7? 'high': Math.random()>0.4? 'medium':'low', confidence: Math.floor(60+Math.random()*40), vehicle: 'VEH-'+Math.floor(Math.random()*999), rsu: 'RSU-'+(1+Math.floor(Math.random()*12)), ts: Date.now(), summary:'Auto generated event', status:'new' }; const db=readDB(); db.incidents.push(inc); writeDB(db); broadcast({type:'incident', data: inc}); }, 15000);

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=>console.log(`Server running on http://localhost:${PORT}`));