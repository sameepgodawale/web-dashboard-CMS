# VANET CMS — Demo Project

This is a demo project that includes a frontend (static) and a simple Node.js backend which emits simulated incidents over WebSocket.

## How to run (locally)

1. Open a terminal in the project folder.
2. Install dependencies:

```bash
npm install
```

3. Start the server:

```bash
npm start
```

4. Open `http://localhost:3000/index.html` in your browser.

## Files
- `public/` — Static frontend files (index.html, devices.html, incident.html, assets)
- `server.js` — Express + ws demo server
- `data/db.json` — Simple JSON storage for devices & incidents

The server broadcasts auto-generated incidents every 15 seconds and accepts POST `/api/incidents` to add incidents.


## Docker & Postgres

Run with Docker Compose:

```bash
docker-compose up --build
```

This will start Postgres and the web service. The DB init script `init_db.sql` seeds an `admin` user with password `adminpass` (hashed) — change this in production.

Login: POST /api/auth/login with JSON `{ "username":"admin", "password":"adminpass" }` to receive a JWT token. Use the token in `Authorization: Bearer <token>` for protected endpoints.


## Production (with nginx TLS & adminer)

Use `docker-compose.prod.yml` to bring up Postgres, web, nginx (TLS termination) and Adminer.

```bash
docker-compose -f docker-compose.prod.yml up --build
```

This example includes a demo self-signed cert in `nginx/certs/` for local testing. Replace with real certificates in production.

Access the app via `https://localhost/` and Adminer at `http://localhost:8080`.
